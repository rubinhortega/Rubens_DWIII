# Sequencia
print('Primeiro comando')
print('Segundo comando')
print('Terceiro comando')

### Seleção 
condicao = False
if condicao:
    print('passou por aqui 1')
condicao = True
if condicao:
    print('passou por aqui 2')
condicao = True
if condicao:
    print('passou por aqui também 3')


lista = list(range(1,10))
for numero in lista:
    print(numero)


def caixinha_magica(numero1, numero2):
    numero3 = numero1 + numero2
    return numero3

print(caixinha_magica(2,5))
print(caixinha_magica('oi ','mundo'))

print('Testes')
assert caixinha_magica(2,5) == 7
assert caixinha_magica('oi ','mundo') == 'oi mundo'

print('Desafio')
assert caixinha_magica(10,10) == 20
assert caixinha_magica('meu ','dasafio') == 'meu desafio'


print('Primeiro experimento com TDD')

print('Passou por aqui também')

def caixinha_magica2(parametro1, parametro2):
    return parametro1 - parametro2
def caixinha_magica3(parametro1, parametro3):
    return parametro1 * parametro3

assert caixinha_magica2(10, 4) == 6
assert caixinha_magica2(10, 5) == 5
assert caixinha_magica2(10, 15) == -5
assert caixinha_magica3(20, 15) == 5
assert caixinha_magica3(20, 10) == 10
assert caixinha_magica3(10, 10) == 0
assert caixinha_magica3(10, 15) == 0
assert caixinha_magica3(30, 45) == 0

# Strings ( Objetos String)
nome = 'Fatec Araras'
nome = 'Fatec Araras 2'
print(nome)
print(id(nome))
print(nome.upper())

# Lista

lista = []
lista.append('Pão')
lista.append('Queijo')
lista.append('Bacon')

for comida in lista:
    print(comida)


tupla1 = ('Pão','Bacon','Leite','Chocolate')
print(tupla1.count('Pão'))
# Range
r = range(1,15)
print(list(r))

r = range(1,15, 2)
print(list(r))